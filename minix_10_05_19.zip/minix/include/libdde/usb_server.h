#ifndef __LIBDDE_USB_SERVER_H__
#define __LIBDDE_USB_SERVER_H__
/*****************************************************************************
 *         ddekit_usb_server_init                                            *
 ****************************************************************************/
void ddekit_usb_server_init();
#endif /* __LIBDDE_USB_SERVER_H__ */
