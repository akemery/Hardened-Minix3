#include "kernel/kernel.h"

struct __cpu_local_vars __cpu_local_vars CPULOCAL_ARRAY;
