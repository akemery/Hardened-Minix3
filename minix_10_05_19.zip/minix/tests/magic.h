
#define MAGIC1 0x12C0ED
#define MAGIC2 0x12C0FF
#define MAGIC3 0x12D0FF
#define MAGIC4 0x13D0FE
#define MAGIC5 0x14D1FF
#define MAGIC6 0x17D1FF

long hellodriver(void);
long modfunction(long, long *, long);
