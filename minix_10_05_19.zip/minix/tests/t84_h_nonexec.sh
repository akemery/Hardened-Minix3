#! /nonexistent

# this is just a dummy script, trying to be non-executable
