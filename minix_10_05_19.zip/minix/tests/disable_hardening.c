#include <unistd.h>

int main(void){
   disable_hardening();
   return(0);
}
