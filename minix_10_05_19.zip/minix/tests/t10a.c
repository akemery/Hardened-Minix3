#include <stdlib.h>

int main(void);

int main()
{
  exit(0);
}
