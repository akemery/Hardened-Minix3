#define HTASK_EN_HARDENING_ALL_F     0x1 
#define HTASK_DIS_HARDENING_ALL_F    0x2
#define HTASK_EN_HARDENING_PID       0x4
#define HTASK_DIS_HARDENING_PID      0x8

#define PID_NONE -10
#define HFAILED  -20
#define OK 0
