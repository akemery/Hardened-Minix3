#include <unistd.h>

int main(void){
   enable_hardening();
   return(0);
}
