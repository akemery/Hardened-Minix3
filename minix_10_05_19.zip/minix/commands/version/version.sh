#!/bin/sh
cat /etc/version
