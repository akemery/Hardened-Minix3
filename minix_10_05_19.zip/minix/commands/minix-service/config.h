
struct rs_config {
	struct rs_start rs_start;	/* RS parameters */
	const char *descr;		/* human-readable description, if specified */
	char *type;			/* service type, if specified */
};

